// =====================================================================
// STARTER PORTFOLIO SCRIPT
//
// JavaScript is the part of a website that can do things, like open
// menus or change text.
//
// This file is optional. Your site works without it. If you do not want it,
// delete the <script> line in your HTML pages.
//
// Anything after two slashes (//) is a comment. It is a note for you.
// The browser ignores it.
// =====================================================================


// ---------------------------------------------------------------------
// KEEP THE FOOTER YEAR UP TO DATE
// This way you never have to change the year by hand.
// ---------------------------------------------------------------------

// Step 1: find the <span id="year"> in the footer.
// querySelector finds one thing on the page. "#year" means "the thing with id year".
// We save it in a variable called yearSpot.
const yearSpot = document.querySelector("#year");

// Step 2: put the current year inside it.
yearSpot.textContent = new Date().getFullYear();


// ---------------------------------------------------------------------
// WANT TO TRY MORE LATER?
// Search for what you want on w3schools.com. For example:
// "w3schools toggle dark mode" or "w3schools image slideshow".
// ---------------------------------------------------------------------
